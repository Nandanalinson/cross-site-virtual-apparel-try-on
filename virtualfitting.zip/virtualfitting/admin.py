from django.contrib import admin
from .models import  usregister


# Register your models here.

admin.site.register(usregister)
