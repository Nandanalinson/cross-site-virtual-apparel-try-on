from pyexpat.errors import messages
from django.shortcuts import render,redirect,get_object_or_404,HttpResponse
from django.contrib import messages
from .models import  usregister
from . import models

# Create your views here.
def index(request):
    return render(request,'index.html')
def home(request):
    return render(request,'home.html')



# def register(request):
#     if request.method=="POST":
#         name=request.POST.get('name')
#         phone_number=request.POST.get('phonenumber')
#         gender=request.POST.get('gender')
#         email=request.POST.get('email') 
#         password=request.POST.get('password')
#         confirm_password=request.POST.get('confirmpassword')
#         image=request.FILES.get('image')
#         if password==confirm_password:
#             user=usregister(name=name,phone_number=phone_number,image=image,gender=gender,email=email,password=password,confirm_password=confirm_password)
#             user.save()
#             return redirect('login')
#         return render(request,'register.html',{'error':'password is Invalid'})
#     return render(request,'register.html')

from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from .models import usregister

def register(request):
    if request.method == "POST":
        name = request.POST.get('name')
        phone_number = request.POST.get('phonenumber')
        gender = request.POST.get('gender')
        email = request.POST.get('email') 
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirmpassword')
        image = request.FILES.get('image')

        if password == confirm_password:
            hashed_password = make_password(password)  # Encrypt password
            user = usregister(
                name=name,
                phone_number=phone_number,
                image=image,
                gender=gender,
                email=email,
                password=hashed_password,  # Store encrypted password
                confirm_password=hashed_password
            )
            user.save()
            return redirect('login')
        
        return render(request, 'register.html', {'error': 'Passwords do not match'})

    return render(request, 'register.html')


# def login(request):
#     if request .method =='POST':
#         email=request.POST.get('email')
#         password=request.POST.get('password')
#         cr=usregister.objects.filter(email=email,password=password)
#         if cr:
#             u=usregister.objects.get(email=email,password=password)
#             email=u.email
#             password=u.password
#             request.session['email']=email
#             request.session['password']=password
#             return redirect ('home')
#         return render(request,'login.html')
#     return render(request,'login.html') 

from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from .models import usregister

def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        try:
            user = usregister.objects.get(email=email)  # Get user by email
            if check_password(password, user.password):  # Verify hashed password
                request.session['email'] = user.email
                return redirect('home')
            else:
                return render(request, 'login.html', {'error': 'Invalid email or password'})
        except usregister.DoesNotExist:
            return render(request, 'login.html', {'error': 'Invalid email or password'})

    return render(request, 'login.html')


def profile(request):
    if 'email' in request.session:
        email=request.session['email']
        user=usregister.objects.get(email=email) 
    return render(request,'profile.html',{'u':user})       
                
def edit_profile(request,eid):
    edit=usregister.objects.get(id=eid)
    if request.method =="POST":
        name=request.POST.get('name')
        phone_number=request.POST.get('phone_number')
        password=request.POST.get('password')
        image=request.FILES.get('image')
        edit.name=name
        edit.phone_number=phone_number
        edit.password=password
        if image is not None:
            edit.image=image
        im=edit.image
        edit.image=im
        edit.save()
        return redirect('profile')
    return render(request,'edit.html',{'edit':edit})
       

def user_list(request):
    users = usregister.objects.all() 
    return render(request, 'userlist.html', {'users': users})

def delete_user(request,did):
    x=usregister.objects.get (id=did)
    x.delete()
    return redirect('user_list')  
    
    

def adminindex(request):
    return render(request,'adminindex.html') 

def adminlog(request):
   if request .method=="POST":
       uname=request.POST.get('username')
       psword=request.POST.get('password')
       u='admin'
       p='admin'
       if uname==u:
            if psword==p:
                request.session['uname']=uname
                return redirect('adminindex')
       return render(request,'adminlogin.html')
   return render(request,'adminlogin.html')

from django.conf import settings

from django.http import JsonResponse


def logout(request):
    request.session.flush()
    return redirect('index')




from .utils import search_dresses  # assuming search_dresses is in utils.py

def dress_search(request):
    if request.method == 'POST':
        style = request.POST.get('style')
        gender = request.POST.get('gender')
        api_key = settings.SEPAPI_KEY
        
        # Pass gender to search_dresses
        dresses = search_dresses(style, api_key, gender)
        
        return render(request, 'dress_results.html', {'dresses': dresses})
    
    return render(request, 'dress_search.html')

# tryon/views.py
import http.client
import os
from django.shortcuts import render
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.http import JsonResponse
import requests
from django.conf import settings
# tryon/views.py
from django.shortcuts import render, redirect
from django.http import JsonResponse
import requests
import os
from django.conf import settings

import cloudinary
import cloudinary.uploader

cloudinary.config(
  cloud_name=settings.CLOUDINARY_CLOUD_NAME,
  api_key=settings.CLOUDINARY_API_KEY,
  api_secret=settings.CLOUDINARY_API_SECRET,
)

def upload_to_cloudinary(image_file):
    # Perform transformation (resize to 1280x1920 and convert to .jpg)
    response = cloudinary.uploader.upload(
        image_file,
        transformation=[
            {'width': 1280, 'height': 1920, 'crop': 'fill', 'format': 'jpg'}
        ]
    )
    print("Upload", response)
    return response['secure_url']

def try_on_page(request):
    dress_url = request.GET.get('dress_url')
    print('hi',dress_url)
    if request.method == 'POST':
        avatar_image = request.FILES.get('avatar_image')
        print('hello',avatar_image)
        
        if not dress_url or not avatar_image:
            return JsonResponse({'error': 'Both dress URL and avatar image are required.'}, status=400)

        try:
            avatar_url = upload_to_cloudinary(avatar_image)
            print('Uploading', avatar_url)
            
            # Proceed with the rest of your logic here
            params = {
                'clothing_image_url': dress_url,
                'avatar_image_url': avatar_url
            }
            
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-RapidAPI-Key': '8e1c63d727msh9f5140132a617e5p199b86jsn47ae00f4ad40',
                'X-RapidAPI-Host': 'try-on-diffusion.p.rapidapi.com'
            }

            # Make the API request as before
            response = requests.post(
                'https://try-on-diffusion.p.rapidapi.com/try-on-url',
                headers=headers,
                data=params
            )
            
            content_type = response.headers.get('Content-Type')
            if content_type == 'image/jpeg':
                # Save the image result in media directory
                result_dir = os.path.join(settings.BASE_DIR, 'media', 'tryon')
                os.makedirs(result_dir, exist_ok=True)
                result_path = os.path.join(result_dir, 'result.jpg')

                with open(result_path, 'wb') as output_file:
                    output_file.write(response.content)
                
                # Use relative URL for media file
                result_image_url = f'/media/tryon/result.jpg'

                # Return the relative URL of the saved image
                return render(request, 'try_on_result.html', {'result_image': result_image_url})

            elif content_type == 'application/json':
                # Handle JSON error response
                response_json = response.json()
                print(response_json)
                return JsonResponse({'error': response_json.get('error', 'Unknown error occurred')}, status=500)

            else:
                response_json = response.json()
                print(response_json)
                # Handle unexpected content types
                return JsonResponse({'error': 'Unexpected response format received.'}, status=500)
        
        except requests.exceptions.RequestException as error:
            return JsonResponse({'error': f'Network error occurred: {str(error)}'}, status=500)

    return render(request, 'try_on_page.html', {'dress_url': dress_url})

def try_on_page_single(request):
    if request.method == 'POST':
        avatar_image = request.FILES.get('avatar_image')
        print('hello',avatar_image)
        dress_image = request.FILES.get('dress_image')
        print('hello1',dress_image)



        try:
            avatar_url = upload_to_cloudinary(avatar_image)
            dress_url = upload_to_cloudinary(dress_image)
            print('Uploading', avatar_url)
            
            # Proceed with the rest of your logic here
            params = {
                'clothing_image_url': dress_url,
                'avatar_image_url': avatar_url
            }
            
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-RapidAPI-Key': '8e1c63d727msh9f5140132a617e5p199b86jsn47ae00f4ad40',
                'X-RapidAPI-Host': 'try-on-diffusion.p.rapidapi.com'
            }

            # Make the API request as before
            response = requests.post(
                'https://try-on-diffusion.p.rapidapi.com/try-on-url',
                headers=headers,
                data=params
            )
            
            content_type = response.headers.get('Content-Type')
            if content_type == 'image/jpeg':
                # Save the image result in media directory
                result_dir = os.path.join(settings.BASE_DIR, 'media', 'tryon')
                os.makedirs(result_dir, exist_ok=True)
                result_path = os.path.join(result_dir, 'result.jpg')

                with open(result_path, 'wb') as output_file:
                    output_file.write(response.content)
                
                # Use relative URL for media file
                result_image_url = f'/media/tryon/result.jpg'

                # Return the relative URL of the saved image
                return render(request, 'try_on_result_single.html', {'result_image': result_image_url})

            elif content_type == 'application/json':
                # Handle JSON error response
                response_json = response.json()
                print(response_json)
                return JsonResponse({'error': response_json.get('error', 'Unknown error occurred')}, status=500)

            else:
                response_json = response.json()
                print(response_json)
                # Handle unexpected content types
                return JsonResponse({'error': 'Unexpected response format received.'}, status=500)
        
        except requests.exceptions.RequestException as error:
            return JsonResponse({'error': f'Network error occurred: {str(error)}'}, status=500)

    return render(request, 'try_on_page_single.html')

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import cv2
import numpy as np
import mediapipe as mp
from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, JsonResponse
from django.conf import settings
from .models import TryOnSession
import uuid

# Initialize MediaPipe components
mp_face_mesh = mp.solutions.face_mesh
mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose
mp_face_detection = mp.solutions.face_detection

# Initialize face mesh, face detection, and pose detection
face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=True,
    max_num_faces=1,
    min_detection_confidence=0.5)

face_detection = mp_face_detection.FaceDetection(
    model_selection=1,  # 0 for short-range, 1 for full-range
    min_detection_confidence=0.5)

pose = mp_pose.Pose(
    static_image_mode=True,
    min_detection_confidence=0.5)

def upload_ornament(request):
    """View to handle ornament upload and type selection"""
    if request.method == 'POST':
        if 'ornament_image' not in request.FILES:
            return render(request, 'upload_ornament.html', {'error': 'No image uploaded'})
        
        # Save the uploaded ornament image
        ornament_image = request.FILES['ornament_image']
        ornament_type = request.POST.get('ornament_type')
        
        if not ornament_type or ornament_type not in ['glasses', 'necklace', 'earrings']:
            return render(request, 'upload_ornament.html', {'error': 'Invalid ornament type'})
        
        # Generate a unique session ID
        session_id = str(uuid.uuid4())
        
        # Create directory for this session
        session_dir = os.path.join(settings.MEDIA_ROOT, 'sessions', session_id)
        os.makedirs(session_dir, exist_ok=True)
        
        # Save ornament image
        ornament_path = os.path.join(session_dir, f'ornament.jpg')
        with open(ornament_path, 'wb+') as destination:
            for chunk in ornament_image.chunks():
                destination.write(chunk)
        
        # Create a session record
        TryOnSession.objects.create(
            session_id=session_id,
            ornament_type=ornament_type,
            ornament_path=ornament_path
        )
        
        # Redirect to the try-on page
        return redirect('try_on', session_id=session_id)
    
    return render(request, 'upload_ornament.html')

def try_on(request, session_id):
    """View to handle person image upload and try-on process"""
    try:
        session = TryOnSession.objects.get(session_id=session_id)
    except TryOnSession.DoesNotExist:
        return redirect('upload_ornament')
    
    if request.method == 'POST' and 'person_image' in request.FILES:
        # Save the uploaded person image
        person_image_file = request.FILES['person_image']
        person_image_path = os.path.join(settings.MEDIA_ROOT, 'sessions', session_id, 'person.jpg')
        
        with open(person_image_path, 'wb+') as destination:
            for chunk in person_image_file.chunks():
                destination.write(chunk)
        
        # Process images
        result_image, message = process_images(
            person_image_path, 
            session.ornament_path, 
            session.ornament_type
        )
        
        if result_image is not None:
            # Save the result image
            result_image_path = os.path.join(settings.MEDIA_ROOT, 'sessions', session_id, 'result.jpg')
            cv2.imwrite(result_image_path, result_image)
            
            # Update session with result path
            session.result_path = result_image_path
            session.save()
            
            result_url = os.path.join(settings.MEDIA_URL, 'sessions', session_id, 'result.jpg')
            return render(request, 'try_on_ornament_result.html', {
                'result_image': result_url,
                'session_id': session_id
            })
        else:
            return render(request, 'try_on_ornament.html', {
                'error': message,
                'session_id': session_id
            })
    
    return render(request, 'try_on_ornament.html', {'session_id': session_id})

def remove_background(image):
    # Convert to RGBA if not already
    if image.shape[2] == 3:
        image_rgba = cv2.cvtColor(image, cv2.COLOR_BGR2BGRA)
    else:
        image_rgba = image

    # Simple background removal - convert white/light backgrounds to transparent
    # Create a mask for light pixels
    mask = cv2.inRange(image_rgba[:,:,:3], np.array([200, 200, 200]), np.array([255, 255, 255]))

    # Set alpha channel to 0 where mask is white (background)
    image_rgba[:, :, 3] = np.where(mask == 255, 0, 255)

    return image_rgba

# Function to detect facial landmarks using MediaPipe
def detect_face_landmarks(image):
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(image_rgb)
    return results

# Function to detect face using MediaPipe Face Detection
def detect_face(image):
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = face_detection.process(image_rgb)
    return results

# Function to detect body landmarks using MediaPipe
def detect_body_landmarks(image):
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = pose.process(image_rgb)
    return results

# Function to get face size for better scaling
def get_face_size(image):
    # Try to get face size using face detection first
    face_results = detect_face(image)
    if face_results.detections:
        detection = face_results.detections[0]
        bounding_box = detection.location_data.relative_bounding_box

        # Convert relative coordinates to absolute
        height, width, _ = image.shape
        x_min = int(bounding_box.xmin * width)
        y_min = int(bounding_box.ymin * height)
        box_width = int(bounding_box.width * width)
        box_height = int(bounding_box.height * height)

        return box_width, box_height

    # Fallback to face mesh if face detection fails
    face_mesh_results = detect_face_landmarks(image)
    if face_mesh_results.multi_face_landmarks:
        landmarks = face_mesh_results.multi_face_landmarks[0].landmark

        # Get face bounds from landmarks
        min_x = min(landmarks, key=lambda l: l.x).x
        max_x = max(landmarks, key=lambda l: l.x).x
        min_y = min(landmarks, key=lambda l: l.y).y
        max_y = max(landmarks, key=lambda l: l.y).y

        height, width, _ = image.shape
        face_width = int((max_x - min_x) * width)
        face_height = int((max_y - min_y) * height)

        return face_width, face_height

    # If all detection methods fail, return a default proportion of image size
    height, width, _ = image.shape
    return width // 3, height // 3  # Default to 1/3 of image dimensions

# Function to place glasses on face with adaptive sizing
def place_glasses(person_image, glasses_image):
    # Get face landmarks
    face_results = detect_face_landmarks(person_image)

    if not face_results.multi_face_landmarks:
        return person_image, False

    face_landmarks = face_results.multi_face_landmarks[0]

    # Get key landmarks for glasses placement
    left_eye = np.array([int(face_landmarks.landmark[33].x * person_image.shape[1]),
                         int(face_landmarks.landmark[33].y * person_image.shape[0])])
    right_eye = np.array([int(face_landmarks.landmark[263].x * person_image.shape[1]),
                          int(face_landmarks.landmark[263].y * person_image.shape[0])])

    # Calculate distance between eyes for horizontal scaling
    eye_distance = np.linalg.norm(right_eye - left_eye)

    # Get face width for better proportional sizing
    face_width, face_height = get_face_size(person_image)

    # Calculate temple width (usually wider than eye distance)
    temple_width = face_width * 0.9  # 90% of face width

    # Adjust glasses width based on temple width
    glasses_width = int(temple_width)
    glasses_height = int(glasses_width * glasses_image.shape[0] / glasses_image.shape[1])

    # Fine-tune vertical position based on face proportions
    vertical_offset_factor = face_height * 0.05  # 5% of face height

    # Resize glasses
    glasses_resized = cv2.resize(glasses_image, (glasses_width, glasses_height), interpolation=cv2.INTER_AREA)

    # Calculate position to place glasses
    center_x = (left_eye[0] + right_eye[0]) // 2
    center_y = (left_eye[1] + right_eye[1]) // 2

    # Adjust vertical position (slightly above eyes)
    center_y -= int(vertical_offset_factor)

    # Create a copy of the person image
    result_image = person_image.copy()

    # Define the region to place glasses
    x_offset = center_x - glasses_width // 2
    y_offset = center_y - glasses_height // 2

    # Place glasses on the face
    for i in range(glasses_height):
        for j in range(glasses_width):
            if (y_offset + i >= 0 and y_offset + i < result_image.shape[0] and
                x_offset + j >= 0 and x_offset + j < result_image.shape[1]):

                # For 4-channel images (with alpha)
                if glasses_resized.shape[2] == 4 and glasses_resized[i, j, 3] > 0:
                    alpha = glasses_resized[i, j, 3] / 255.0
                    result_image[y_offset + i, x_offset + j] = (
                        (1 - alpha) * result_image[y_offset + i, x_offset + j] +
                        alpha * glasses_resized[i, j, :3]
                    ).astype(np.uint8)

    return result_image, True

# Function to place necklace on person with adaptive sizing
def place_necklace(person_image, necklace_image):
    # Get body landmarks
    body_results = detect_body_landmarks(person_image)

    if not body_results.pose_landmarks:
        return person_image, False

    landmarks = body_results.pose_landmarks

    # Get shoulder landmarks
    left_shoulder = np.array([int(landmarks.landmark[mp_pose.PoseLandmark.LEFT_SHOULDER].x * person_image.shape[1]),
                              int(landmarks.landmark[mp_pose.PoseLandmark.LEFT_SHOULDER].y * person_image.shape[0])])
    right_shoulder = np.array([int(landmarks.landmark[mp_pose.PoseLandmark.RIGHT_SHOULDER].x * person_image.shape[1]),
                               int(landmarks.landmark[mp_pose.PoseLandmark.RIGHT_SHOULDER].y * person_image.shape[0])])

    # Get face landmarks to calculate neck width
    face_results = detect_face_landmarks(person_image)
    neck_width = None

    if face_results.multi_face_landmarks:
        face_landmarks = face_results.multi_face_landmarks[0]

        # Using jaw landmarks (jawline endpoints) to estimate neck width
        left_jawline = np.array([int(face_landmarks.landmark[149].x * person_image.shape[1]),
                               int(face_landmarks.landmark[149].y * person_image.shape[0])])
        right_jawline = np.array([int(face_landmarks.landmark[378].x * person_image.shape[1]),
                                int(face_landmarks.landmark[378].y * person_image.shape[0])])

        # The neck is typically narrower than the jaw
        jaw_width = np.linalg.norm(right_jawline - left_jawline)
        neck_width = jaw_width * 0.8  # Neck is approximately 80% of jaw width
    else:
        # Fallback if no face landmarks
        shoulder_distance = np.linalg.norm(right_shoulder - left_shoulder)
        neck_width = shoulder_distance * 0.4  # Neck is typically 40% of shoulder width

    # Calculate position for necklace
    shoulder_distance = np.linalg.norm(right_shoulder - left_shoulder)
    center_x = (left_shoulder[0] + right_shoulder[0]) // 2

    # Estimate neck position
    if hasattr(mp_pose.PoseLandmark, 'NOSE'):
        nose_y = int(landmarks.landmark[mp_pose.PoseLandmark.NOSE].y * person_image.shape[0])
        shoulder_y = (left_shoulder[1] + right_shoulder[1]) // 2

        # Neck is positioned between nose and shoulders, closer to shoulders
        neck_y = nose_y + int((shoulder_y - nose_y) * 0.3)
    else:
        # Fallback if nose isn't detected
        neck_y = (left_shoulder[1] + right_shoulder[1]) // 2 - int(shoulder_distance * 0.2)

    # Use neck width for necklace sizing
    necklace_width = int(neck_width * 4.2)  # Necklace typically drapes beyond neck width

    # Maintain aspect ratio
    necklace_height = int(necklace_width * necklace_image.shape[0] / necklace_image.shape[1])

    # Resize necklace
    necklace_resized = cv2.resize(necklace_image, (necklace_width, necklace_height), interpolation=cv2.INTER_AREA)

    # Create a copy of the person image
    result_image = person_image.copy()

    # Define the region to place necklace
    x_offset = center_x - necklace_width // 2
    y_offset = neck_y - int(necklace_height * 0.001)   # Position at the neck

    # Place necklace on the person
    for i in range(necklace_height):
        for j in range(necklace_width):
            if (y_offset + i >= 0 and y_offset + i < result_image.shape[0] and
                x_offset + j >= 0 and x_offset + j < result_image.shape[1]):

                # For 4-channel images (with alpha)
                if necklace_resized.shape[2] == 4 and necklace_resized[i, j, 3] > 0:
                    alpha = necklace_resized[i, j, 3] / 255.0
                    result_image[y_offset + i, x_offset + j] = (
                        (1 - alpha) * result_image[y_offset + i, x_offset + j] +
                        alpha * necklace_resized[i, j, :3]
                    ).astype(np.uint8)

    return result_image, True

# Function to place earrings with adaptive sizing
def place_earrings(person_image, earring_image):
    # Get face landmarks
    face_results = detect_face_landmarks(person_image)

    if not face_results.multi_face_landmarks:
        return person_image, False

    face_landmarks = face_results.multi_face_landmarks[0]

    # Get ear landmarks (234 is right ear, 454 is left ear in MediaPipe Face Mesh)
    left_ear = np.array([int(face_landmarks.landmark[234].x * person_image.shape[1]),
                         int(face_landmarks.landmark[234].y * person_image.shape[0])])
    right_ear = np.array([int(face_landmarks.landmark[454].x * person_image.shape[1]),
                          int(face_landmarks.landmark[454].y * person_image.shape[0])])

    # Get face size for proportional scaling
    face_width, face_height = get_face_size(person_image)

    # Calculate appropriate earring size based on face proportions
    face_ratio = face_width / face_height

    # Adjust earring size based on face shape
    if face_ratio < 0.7:  # Narrower face
        earring_scale = 0.15  # Smaller earrings
    elif face_ratio > 0.9:  # Wider face
        earring_scale = 0.25  # Larger earrings
    else:
        earring_scale = 0.2  # Default

    # Calculate earring size proportional to face dimensions
    earring_size = int(face_width * earring_scale)
    earring_resized = cv2.resize(earring_image, (earring_size, earring_size), interpolation=cv2.INTER_AREA)

    # Create a copy of the person image
    result_image = person_image.copy()

    # Place earrings on both ears
    for ear_pos in [left_ear, right_ear]:
        # Create a little gap from the ear by adjusting x_offset
        if np.array_equal(ear_pos, left_ear):
            x_offset = ear_pos[0] - earring_size // 2 - int(earring_size * 0.15)
        else:  # right ear
            x_offset = ear_pos[0] - earring_size // 2 + int(earring_size * 0.15)

        # Move earrings downward by adding pixels to y_offset
        y_offset = ear_pos[1] + int(earring_size * 0.2)

        # Place earring
        for i in range(earring_size):
            for j in range(earring_size):
                if (y_offset + i >= 0 and y_offset + i < result_image.shape[0] and
                    x_offset + j >= 0 and x_offset + j < result_image.shape[1]):

                    # For 4-channel images (with alpha)
                    if earring_resized.shape[2] == 4 and earring_resized[i, j, 3] > 0:
                        alpha = earring_resized[i, j, 3] / 255.0
                        result_image[y_offset + i, x_offset + j] = (
                            (1 - alpha) * result_image[y_offset + i, x_offset + j] +
                            alpha * earring_resized[i, j, :3]
                        ).astype(np.uint8)

    return result_image, True

# Main function to process images
def process_images(person_image_path, ornament_image_path, ornament_type):
    # Read images
    person_image = cv2.imread(person_image_path)
    ornament_image = cv2.imread(ornament_image_path, cv2.IMREAD_UNCHANGED)

    # Check if images were loaded properly
    if person_image is None or ornament_image is None:
        return None, "Failed to load images"

    # Preprocess the ornament image (remove background if needed)
    if ornament_image.shape[2] == 3:  # If RGB (no alpha channel)
        ornament_image = remove_background(ornament_image)

    # Process based on ornament type
    success = False
    if ornament_type.lower() == 'glasses':
        result_image, success = place_glasses(person_image, ornament_image)
    elif ornament_type.lower() == 'necklace':
        result_image, success = place_necklace(person_image, ornament_image)
    elif ornament_type.lower() == 'earrings':
        result_image, success = place_earrings(person_image, ornament_image)
    else:
        return None, f"Unsupported ornament type: {ornament_type}"

    if not success:
        return None, f"Failed to place {ornament_type}. Could not detect required landmarks."

    return result_image, "Success"
