from django.urls import path
from virtualfitting import views

urlpatterns=[
    path('',views.index,name='index'),
    path('register/',views.register,name='register'),
    path('login/',views.login,name='login'),
    path('home/',views.home,name='home'),
    path('profile/',views.profile,name='profile'),
    path('edit/<int:eid>/',views.edit_profile,name='edit_profile'),
    path('userlist/', views.user_list, name='user_list'),
    path('delete_user/<int:did>/',views.delete_user,name='delete_user'),
    path('adminindex/', views.adminindex, name='adminindex'),
    path('adminlogin/', views.adminlog, name='adminlog'),
    
    path('logout/',views.logout,name='logout'),




    path('dress_search/',views.dress_search, name='dress_search'),
    path('dress-search/',views.dress_search, name='dress_search'),
    path('try_on_page/',views.try_on_page, name='try_on_page'),
    path('try_on_page_single/',views.try_on_page_single, name='try_on_page_single'),
    
    path('upload-ornament/', views.upload_ornament, name='upload_ornament'),
    path('try-on/<str:session_id>/', views.try_on, name='try_on'),



]