from django.apps import AppConfig


class VirtualfittingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'virtualfitting'
