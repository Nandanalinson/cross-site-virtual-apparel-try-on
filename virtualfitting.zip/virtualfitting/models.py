from django.db import models # type: ignore

# Create your models here.
class usregister(models.Model):
    name=models.CharField(max_length=50,null=True,blank=True)
    phone_number=models.IntegerField(null=True,blank=True)
    gender_choices=(
        ('MALE','male'),
        ('FEMALE','female'),
    )
    gender=models.CharField(max_length=10,choices=gender_choices,null=True,blank=True)
    email=models.CharField(unique=True,max_length=50,null=True,blank=True)
    password=models.CharField(max_length=10,null=True,blank=True)
    confirm_password=models.CharField(max_length=10,null=True,blank=True)
    image=models.ImageField(upload_to='image/',null=True,blank=True)
    
    def __str__(self):
            return self.name


class fileupload(models.Model):
    image = models.ImageField(upload_to='media/')

    def __str__(self):
        return self.image.name
    
from django.db import models
import uuid

class TryOnSession(models.Model):
    """Model to store try-on session data"""
    session_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    ornament_type = models.CharField(max_length=50)
    ornament_path = models.CharField(max_length=255)
    result_path = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.ornament_type} - {self.session_id}"